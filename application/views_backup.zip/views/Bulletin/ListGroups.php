<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Bulletins/AddGroup');?>">
		<button type="button" class="btn btn-success">ADD GROUP</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('group_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('group_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('group_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('group_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('group_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('group_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Group Name</th>
				<th>Employees</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $sno = 1; foreach ($Groups as $group) : ?>
			<tr>
				<td><?= $sno++; ?></td>
				<td><?= $group->group_name; ?></td>
				<td><?= $group->employees; ?></td>
				<td>
					<a href="<?= base_url('Bulletins/UpdateGroup/'.$group->id); ?>">
						<button class="btn btn-sm btn-secondary">Update</button>
					</a>
					&nbsp;
					<a href="<?= base_url('Bulletins/DeleteGroup/'.$group->id); ?>">
						<button class="btn btn-sm btn-danger">Delete</button>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addGroupForm');
	echo form_open('Bulletins/AddGroupOps', $attributes);
	echo form_hidden('employee_id'); ?>
	<fieldset>
		<legend>Add Group</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Group Name*</label>
							<input type="text" name="group_name" value="<?= set_value('group_name'); ?>" class="form-control" placeholder="Enter Group name" maxlength="100"> 
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('group_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row" id="dynamicEmpAdding" style="display: none">
		</div>
		<div class="row">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>S.No</th>
						<th>Employee</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $sno = 1; foreach ($employees as $employee) : ?>
					<tr>
						<td><?= $sno++; ?></td>
						<td><?= $employee->employee_username; ?></td>
						<td>
							<button type="button" id="<?= $employee->employee_id; ?>" class="btn btn-sm btn-danger addEmpToGroup">ADD</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<a href="<?= base_url('Bulletins/ListGroups'); ?>">
		<button type="button" id="backFromAddGroups" class="btn btn-secondary">Back</button>
	</a>
	&nbsp;
	<button type="button" id="addGroupButton" class="btn btn-primary">Add Group</button>
</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Bulletin.js').'?v='.time(); ?>"></script>

<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addMessageForm');
	echo form_open('Bulletins/AddMessageOps', $attributes); ?>
	<fieldset>
		<legend>Add Message</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Select Group</label>
							<select class="form-control" name="group_id">
								<option value="0">No Groups</option>
								<?php foreach ($groups as $group) : ?>
									<option value="<?= $group->id; ?>"> <?= $group->group_name; ?> </option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Select Individual Employee</label>
							<select class="form-control" name="individual_id">
								<option selected="selected" value="0">No individual participants</option>
								<?php foreach ($employees as $employee) : ?>
									<option value="<?= $employee->employee_id; ?>"> <?= $employee->employee_username; ?> </option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Type the message</label>
							<textarea rows="5" name="message" class="form-control" placeholder="Enter message"><?= set_value('message'); ?></textarea> 
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('message', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Bulletins/ListMessages'); ?>">
			<button type="button" id="backFromAddMessage" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addMessageButton" class="btn btn-primary">Send</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Bulletin.js').'?v='.time(); ?>"></script>

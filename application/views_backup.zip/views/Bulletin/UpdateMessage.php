<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateMessageForm');
	echo form_open('Bulletins/UpdateMessageOps/'.$message->id, $attributes); ?>
	<fieldset>
		<legend>Update Message</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Select Group</label>
							<?php
							$optionsNew["0"] = "No Groups";
							foreach ($groups as $group) : 
								$optionsNew[$group->id] = $group->group_name;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('group_id', $optionsNew, $message->group_id, $atts); ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Select Individual Employee</label>
							<?php
							$options["0"] = "No individual participants";
							foreach ($employees as $employee) : 
								$options[$employee->employee_id] = $employee->employee_username;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('individual_id', $options, $message->individual_id, $atts); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Type the message</label>
							<textarea rows="5" name="message" class="form-control" placeholder="Enter message"><?= $message->message; ?></textarea> 
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('message', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Bulletins/ListMessages'); ?>">
			<button type="button" id="backFromAddMessage" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateMessageButton" class="btn btn-primary">Update Message</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Bulletin.js').'?v='.time(); ?>"></script>

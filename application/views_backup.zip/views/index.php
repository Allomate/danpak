<?php require_once(APPPATH.'/views/includes/header.php'); ?>
<div class="preloader-it">
	<div class="la-anim-1"></div>
</div>
<div class="wrapper theme-1-active">
	<?php require_once(APPPATH.'/views/includes/navbar&sidebar.php'); ?>
	<div class="page-wrapper">
		<div class="container">
			<div class="row m-t-30">
				<div class="col-md-12 align-center">
					<h1 class="txt-dark">Heading Here... Why do we use it?</h1>
					<h3 class="txt-grey">It is a long established fact that a reader will be distracted by the readable.</h3>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 m-t-30">
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-dash2-icon"></span>			    		
							<a href="#">Dashboard</a>			    			
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-inv2-icon"></span>			    		
							<a href="#">Inventory Management</a>			    			
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-emp2-icon"></span>			    		
							<a href="#">Organization Management</a>			    			
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-cat2-icon"></span>			    		
							<a href="#">Catalogue Management</a>			    			
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-ret2-icon"></span>			    		
							<a href="#">Retailers Management</a>			    			
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-sec">
							<span class="icon-ord2-icon"></span>			    		
							<a href="#">Orders Management </a>			    			
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
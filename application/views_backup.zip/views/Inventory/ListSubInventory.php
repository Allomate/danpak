<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Inventory/AddSubInventory');?>">
		<button type="button" class="btn btn-success">Add Sub-Inventory</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('sub_invent_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_invent_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_convert_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Each Parent</th>
				<th>Quantity</th>
				<th>Childeren</th>
			</tr>
		</thead>
		<tbody>
			<?php $sno = 1; foreach ($SubInventory as $inventory) : ?>
			<tr>
				<td><?= $sno++; ?></td>
				<td><?= $inventory->inside_this_item; ?></td>
				<td><?= $inventory->quantity; ?></td>
				<td><?= $inventory->item_inside; ?></td>
				<td>
					<a href="<?= base_url('Inventory/UpdateSubInventory/'.$inventory->id); ?>">
						<button class="btn btn-sm btn-secondary">Update</button>
					</a>
					&nbsp;
					<a href="<?= base_url('Inventory/ConvertTo/'.$inventory->id); ?>">
						<button class="btn btn-sm btn-warning">Convert</button>
					</a>
					&nbsp;
					<a href="<?= base_url('Inventory/DeleteSubInventory/'.$inventory->id); ?>">
						<button class="btn btn-sm btn-danger">Delete</button>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
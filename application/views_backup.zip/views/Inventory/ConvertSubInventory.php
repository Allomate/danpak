<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'convertQuantityForm');
	echo form_open('Inventory/ConvertSubInventoryOps/'.$SubInventoryData->id, $attributes);
	echo form_hidden('each_parent_contains_quantity', $SubInventoryData->quantity);
	echo form_hidden('quantityAddingToChild');
	echo form_hidden('quantityRemainingForParent');?>
	<fieldset>
		<legend>Convert Item</legend>
		<div class="row">
			<div class="col-md-12">
				<br>
				<div class="row">
					<div class="col-md-4">
						<h5>Parent Item: </h5>
						<strong><?= $SubInventoryData->parent_item; ?></strong>
					</div>
					<div class="col-md-4">
						<h5>Child Item: </h5>
						<strong><?= $SubInventoryData->child_item; ?></strong>
					</div>
				</div>
				<br>
				<h4>Information</h4>
				<p>
					<strong><?= $SubInventoryData->parent_item; ?></strong> quantity is: <strong><?= $SubInventoryData->parent_quantity; ?></strong> and Each <strong><?= $SubInventoryData->parent_item; ?></strong> contains <strong><?= $SubInventoryData->quantity;?></strong> quantity of <strong><?= $SubInventoryData->child_item; ?></strong>
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<div class="form-group">
					<label>Convert Parent Quantity</label>
					<input type="number" name="convert_parent_quantity" class="form-control" placeholder="Add parent quantity to convert to child" max="<?= $SubInventoryData->parent_quantity; ?>" min="1">
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label>Quantity Add To <strong><?= $SubInventoryData->child_item; ?></strong> - Child</label>
					<h5 id="quantityAddingToChild"></h5>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label>Remaining Items of <strong><?= $SubInventoryData->parent_item; ?></strong> - Parent</label>
					<h5 id="quantityRemainingForParent"></h5>
				</div>
			</div>
		</div>
		<a href="<?= base_url('Inventory/ListSubInventory'); ?>">
			<button type="button" id="backFromConversionButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="convertQuantityBtn" class="btn btn-primary">Convert</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Inventory.js').'?v='.time(); ?>"></script>

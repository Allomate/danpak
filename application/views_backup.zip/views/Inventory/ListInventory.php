<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Inventory/AddInventory');?>">
		<button type="button" class="btn btn-success">ADD INVENTORY</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('inventory_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('inventory_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('inventory_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('inventory_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_inventory_converted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Converted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<div>
		<img src="<?= base_url('assets/images/table-loader.gif'); ?>" style="top: 40%; left: 50%; position: absolute; width: auto; height: 90px" id="loaderImg">
		<table class="table table-hover" style="display: none">
			<thead>
				<tr>
					<th>Item Sku</th>
					<th>Item Name</th>
					<th>Unit Name</th>
					<th>Quantity</th>
					<th>Retail Price</th>
					<th>Trade Price</th>
					<th>Warehouse Price</th>
					<th>Category</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($inventoryList as $inventory) : ?>
					<tr>
						<td><?= $inventory->item_sku; ?></td>
						<td><?= $inventory->item_name; ?></td>
						<td><?= $inventory->unit_name; ?></td>
						<td><?= $inventory->item_quantity; ?></td>
						<td><?= 'Rs.' . $inventory->item_retail_price; ?></td>
						<td><?= 'Rs.' . $inventory->item_trade_price; ?></td>
						<td><?= 'Rs.' . $inventory->item_warehouse_price; ?></td>
						<td><?= $inventory->sub_category_name; ?></td>
						<td>
							<a href="<?= base_url('Inventory/UpdateInventory/'.$inventory->pref_id); ?>">
								<button class="btn btn-sm btn-secondary">Update</button>
							</a>
							&nbsp;
							<a href="<?= base_url('Inventory/DeleteInventory/'.$inventory->pref_id); ?>">
								<button class="btn btn-sm btn-danger">Delete</button>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Inventory.js').'?v='.time(); ?>"></script>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateInventoryForm');
	echo form_open_multipart('Inventory/UpdateInventoryOps/'.$item->pref_id, $attributes);
	echo form_hidden('images_deleted', '');
	echo form_hidden('existing_images', $item->item_image);
	echo form_hidden('thumb_deleted', ''); ?>
	<fieldset>
		<legend>Update Inventory</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Sku</label>
							<input type="text" name="item_sku" value="<?= $item->item_sku; ?>" class="form-control" placeholder="Enter item sku" maxlength="20"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Name</label>
							<input type="text" name="item_name" value="<?= $item->item_name; ?>" class="form-control" placeholder="Enter Item Name" maxlength="20">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php if(isset($skuExist)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $skuExist['skuExist']; ?> </div> <?php endif;
				echo form_error('item_sku', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Unit Name*</label>
							<?php
							foreach ($UnitTypes as $unit) : 
								$options[$unit->unit_id] = $unit->unit_name;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('unit_id', $options, $item->unit_id, $atts); ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputPassword1">Item Quantity*</label>
							<input type="number" class="form-control" name="item_quantity" value="<?= $item->item_quantity; ?>" placeholder="Item Quantity" maxlength="100" required >
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('unit_id', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php if(isset($PropExist)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $PropExist; ?> </div> <?php endif;
				echo form_error('item_quantity', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<label for="exampleInputEmail1">Sub Category*</label>
							<?php
							foreach ($SubCategories as $category) : 
								$optionsSubCat[$category->sub_category_id] = $category->sub_category_name;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('sub_category_id', $optionsSubCat, $item->sub_category_id, $atts); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('sub_category_id', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Warehouse Price*</label>
							<input type="number" class="form-control" value="<?= $item->item_warehouse_price; ?>" name="item_warehouse_price" placeholder="Enter warehouse price" maxlength="11" required />
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Retail Price*</label>
							<input type="number" name="item_retail_price" value="<?= $item->item_retail_price; ?>" class="form-control" placeholder="Enter retail price" maxlength="11"  required />
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Trade Price*</label>
							<input type="number" name="item_trade_price" value="<?= $item->item_trade_price; ?>" class="form-control" placeholder="Enter trade price" maxlength="11"  required />
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_warehouse_price', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_retail_price', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_trade_price', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Images</label>
							<input type="file" id="item_images" name="item_images[]" data-input="false" multiple="multiple" class="form-control" accept=".png, .jpeg, .jpg, .bmp">
							<small>Max 3 Mb</small>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Thumbnail</label>
							<input type="file" id="item_thumbnail" name="item_thumbnail" data-input="false" class="form-control" accept=".png, .jpeg, .jpg, .bmp">
							<small>Max 3 Mb</small>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php if(isset($item_thumbnail_error)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $item_thumbnail_error; ?> </div> <?php endif;
				if(isset($imagesUploadError)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $imagesUploadError; ?> </div> <?php endif; ?>
			</div>
		</div>
		<?php if ($item->item_image) : ?> 
			<div class="row" id="dynamicItemImagesToDeleteDiv">
				<div class="form-group">
					<h3>Item Images</h3>
					<?php foreach (explode(",", $item->item_image) as $image) : ?>
						<article style="display: inline-block; width: 100px">
							<header>
								<img src="<?= base_url(str_replace("./", "", $image)); ?>" width="100px" height="100px">
							</header>
							<content>
								<span class="deleteImagesSpanTag">DELETE</span>
							</content>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if ($item->item_thumbnail) : ?> 
			<div class="row">
				<div class="form-group">
					<h3>Item Thumbnail</h3>
					<article style="display: inline-block; width: 100px">
						<header>
							<img src="<?= base_url(str_replace("./", "", $item->item_thumbnail)); ?>" width="100px" height="100px">
						</header>
						<content>
							<span class="deleteThumbSpanTag">DELETE</span>
						</content>
					</article>
				</div>
			</div>
		<?php endif; ?>
		<div class="row">
			<div class="col-md-8">
				<div class="form-group">
					<label for="exampleInputEmail1">Item Description</label>
					<textarea type="text" name="item_description" class="form-control" placeholder="Enter item Description" rows="5" maxlength="500"><?= $item->item_description; ?></textarea>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_description', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Inventory/ListInventory'); ?>">
			<button type="button" id="backFromInventoryButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateItemButton" class="btn btn-primary">Update Item</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Inventory.js').'?v='.time(); ?>"></script>

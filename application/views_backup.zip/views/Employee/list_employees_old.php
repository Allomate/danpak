<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Employees/AddEmployee');?>">
		<button type="button" class="btn btn-success">ADD EMPLOYEE</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('update_success')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('employee_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('employee_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Username</th>
				<th>Reporting To</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($employees as $employee) : ?>
				<tr>
					<td><?= $employee->employee_first_name . " " . $employee->employee_last_name; ?></td>
					<td><?= $employee->employee_username; ?></td>
					<td><?= $employee->reporting_to != "" ? $employee->reporting_to : 'No one'; ?></td>
					<td>
						<a href="<?= base_url('Employees/UpdateEmployee/'.$employee->employee_id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Employees/DeleteEmployee/'.$employee->employee_id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addEmployeeForm');
	echo form_open('employees/add_employee_operation', $attributes); ?>
	<fieldset>
		<legend>Add Employee</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">First Name*</label>
							<input type="text" name="employee_first_name" value="<?= set_value('employee_first_name'); ?>" class="form-control" placeholder="Enter first name"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Last Name</label>
							<input type="text" name="employee_last_name" value="<?= set_value('employee_last_name'); ?>" class="form-control" placeholder="Enter last name">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_first_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('employee_last_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Username*</label>
							<input type="text" name="employee_username" value="<?= set_value('employee_username'); ?>" class="form-control" placeholder="Enter Username">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputPassword1">Password*</label>
							<input type="password" class="form-control" name="employee_password" placeholder="Password">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_username', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('employee_password', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleInputEmail1">Reporting To</label>
					<select class="form-control" name="reporting_to">
						<option value="0" disabled="disabled" selected="selected">No reporting</option>
						<?php foreach ($employees as $employee) : ?>
							<option value="<?= $employee->employee_id; ?>"> <?= $employee->employee_username; ?> </option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleInputEmail1">Territory*</label>
					<select class="form-control" id="territoryDD" name="territory_id">
						<option value="0" disabled="disabled" selected="selected">Please select a territory</option>
						<?php foreach ($territories as $territory) : ?>
							<option value="<?= $territory->id; ?>"> <?= $territory->territory_name; ?> </option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-4"></div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Cnic</label>
							<input type="number" name="employee_cnic" value="<?= set_value('employee_cnic'); ?>" class="form-control" placeholder="Enter Cnic" />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Designation*</label>
							<input type="text" class="form-control" value="<?= set_value('employee_designation'); ?>" name="employee_designation" placeholder="Enter designation" />
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_cnic', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('employee_designation', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Phone*</label>
							<input type="number" name="employee_phone" value="<?= set_value('employee_phone'); ?>" class="form-control" placeholder="Enter Number" />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Salary</label>
							<input type="number" name="employee_salary" class="form-control" value="<?= set_value('employee_salary'); ?>" placeholder="Enter Salary" />
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_phone', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('employee_salary', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">City*</label>
							<input type="text" name="employee_city" value="<?= set_value('employee_city'); ?>" class="form-control" placeholder="Enter City">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputPassword1">Country*</label>
							<input type="text" name="employee_country" value="<?= set_value('employee_country'); ?>" class="form-control" placeholder="Country">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_city', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('employee_country', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="form-group">
					<label for="exampleInputEmail1">Address*</label>
					<textarea type="text" name="employee_address" class="form-control" placeholder="Enter Address" rows="5"><?= set_value('employee_address'); ?></textarea>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('employee_address', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Employees/ListEmployees'); ?>">
			<button type="button" id="backFromEmployeeButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addEmployeeButton" class="btn btn-primary">Add Employee</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Employee.js').'?v='.time(); ?>"></script>

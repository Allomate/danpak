<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Catalogue/ViewCatalogues');?>">
		<button type="button" class="btn btn-secondary">GO BACK</button>
	</a>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Catalogue/AssignCatalogue');?>">
		<button type="button" class="btn btn-success">Assign Catalogue</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('catalogue_assigned')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Assigned!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_assignment_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_assignment_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_assignment_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('already_exist')) : ?>
		<div class="alert alert-dismissible alert-warning">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_assignment_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_assignment_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Catalogue</th>
				<th>Assigned To</th>
				<th>Active From</th>
				<th>Active Till</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Assignments as $assignment) : ?>
				<tr>
					<td><?= $assignment->catalogue_name; ?> <a href="" id="<?= $assignment->id; ?>" >(View)</a> </td>
					<td><?= $assignment->employee_username; ?></td>
					<td><?= $assignment->active_from; ?></td>
					<td><?= $assignment->active_till; ?></td>
					<td>
						<a href="<?= base_url('Catalogue/UpdateCatalogueAssignment/'.$assignment->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Catalogue/DeleteCatalogueAssignment/'.$assignment->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
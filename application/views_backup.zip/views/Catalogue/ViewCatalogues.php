<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Catalogue/CreateCatalogue');?>">
		<button type="button" class="btn btn-success">Create Catalogue</button>
	</a>
	<a href="<?= base_url('Catalogue/ViewCatalogueAssignments');?>">
		<button type="button" class="btn btn-success">Catalogue Assignments</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('catalogue_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('catalogue_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th style="max-width: 150px">Inventory</th>
				<th>Created At</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Catalogues as $catalogue) : ?>
				<tr>
					<td><?= $catalogue->catalogue_name; ?> <a href="" class="viewCatalogueContents" id="<?= $catalogue->id; ?>" >(View)</a> </td>
					<td style="max-width: 150px">
							<?= $catalogue->inventory; ?>
					</td>
					<td><?= $catalogue->created_at; ?></td>
					<td>
						<a href="<?= base_url('Catalogue/UpdateCatalogue/'.$catalogue->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Catalogue/DeleteCatalogue/'.$catalogue->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
<input type="text" id="baseUrlField" value="<?= base_url('Catalogue/GetCatalogueContentsAjaxCall');?>" hidden>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<script type="text/javascript" src="<?= base_url('assets/js/ViewCatalogue.js?v='.time());?>"></script>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>
<!-- Page level CSS -->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap-datepicker.min.css'); ?>">

<div class="container">
	<br>
	<?php if ($feedback = $this->session->flashdata('invalid_dates')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Invalid dates!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateCatalogueAssignmentForm');
	echo form_open('Catalogue/UpdateCatalogueAssignmentOps/'.$ThisCatalogue->id, $attributes); ?>
	<fieldset>
		<legend>Update Catalogue Assignment</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Catalogue Name*</label>
							<?php
							foreach ($Catalogues as $catalogue) : 
								$options[$catalogue->id] = $catalogue->catalogue_name;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('catalogue_id', $options, $ThisCatalogue->catalogue_id, $atts); ?>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Active From*</label>
							<div class="input-group date" data-provide="datepicker">
								<input type="text" class="form-control" name="active_from" value="<?= $ThisCatalogue->active_from; ?>" data-date-format="yyyy-mm-dd">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Active Till*</label>
							<div class="input-group date" data-provide="datepicker">
								<input type="text" class="form-control" name="active_till" value="<?= $ThisCatalogue->active_till; ?>" data-date-format="yyyy-mm-dd">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Assign To*</label>
							<?php
							foreach ($Employees as $employee) : 
								$optionsEmployee[$employee->employee_id] = $employee->employee_username;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('employee_id', $optionsEmployee, $ThisCatalogue->employee_id, $atts); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('active_from', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('active_till', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row" style="display: none">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleInputEmail1">Inventory Selected*</label>
					<div id="dynamicInventSelected"></div>
				</div>
			</div>
		</div>
		<a href="<?= base_url('Catalogue/ViewCatalogueAssignments'); ?>">
			<button type="button" id="backFromCataloguesAssignmentButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateAssignmentButton" class="btn btn-primary">UPDATE ASSIGNMENT</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap-datepicker.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/AssignCatalogue.js').'?v='.time(); ?>"></script>

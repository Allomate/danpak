<?php require_once(APPPATH.'/views/includes/header.php'); ?>
<!-- Page level CSS -->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap-datepicker.min.css'); ?>">

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateCatalogueForm');
	echo form_open('Catalogue/UpdateCatalogueOps/'.$CatalogueDetails->id, $attributes); 
	echo form_hidden('pref_id', $CatalogueDetails->pref_id); ?>
	<fieldset>
		<legend>Create Catalogue</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Catalogue Name*</label>
							<input type="text" name="catalogue_name" value="<?= $CatalogueDetails->catalogue_name; ?>" class="form-control" placeholder="Enter Catalogue name" maxlength="100"> 
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('catalogue_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="form-group">
					<h3>Inventory Selected*</h3>
					<br>
					<div id="dynamicInventSelected"></div>
				</div>
			</div>
			<div class="col-md-4" id="prioritySortingCatItems">
				<h3>Priority</h3>
				<br>
				<ol class="limited_drop_targets"></ol>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleInputEmail1">Select Inventory*</label>
					<img src="<?= base_url('assets/images/table-loader.gif'); ?>" style="top: 40%; left: 50%; position: relative; width: auto; height: 90px; display: block;" id="loaderImg">
					<table class="table" style="display: none">
						<thead>
							<tr>
								<th width="150px">Image</th>
								<th>Name</th>
								<th>Unit</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($inventoryList as $inventory) : ?>
								<tr>
									<td>
										<?php if ($inventory->item_thumbnail != '') : ?>
											<img src="<?= base_url(str_replace("./", "", $inventory->item_thumbnail)); ?>" width="150px" height="auto">
										<?php endif; ?>
									</td>
									<td><?= $inventory->item_name; ?></td>
									<td><?= $inventory->unit_name; ?></td>
									<td>
										<button type="button" class="btn btn-primary selectInventButton" id="<?= $inventory->pref_id; ?>">SELECT</button>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<a href="<?= base_url('Catalogue/ViewCatalogues'); ?>">
			<button type="button" id="backFromCataloguesButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateCatalogueButton" class="btn btn-primary">Update Catalogue</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap-datepicker.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/jquery-sortable.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/Catalogue.js').'?v='.time(); ?>"></script>
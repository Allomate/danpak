<?php require_once(APPPATH.'/views/includes/header.php'); ?>
<!-- Page level CSS -->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap-datepicker.min.css'); ?>">

<div class="container">
	<br>
	<?php if ($feedback = $this->session->flashdata('invalid_dates')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Invalid dates!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'assignCatalogueForm');
	echo form_open('Catalogue/AssignCatalogueOps', $attributes); ?>
	<fieldset>
		<legend>Assign Catalogue</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Catalogue Name*</label>
							<select class="form-control" name="catalogue_id" id="catalogueIdDropdown">
								<option value="-1">No catalogue selected</option>
								<?php foreach ($Catalogues as $catalogue) : ?>
									<option value="<?= $catalogue->id ?>"><?= $catalogue->catalogue_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Active From*</label>
							<div class="input-group date" data-provide="datepicker">
								<input type="text" class="form-control" name="active_from" value="<?= set_value('active_from'); ?>" data-date-format="yyyy-mm-dd">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Active Till*</label>
							<div class="input-group date" data-provide="datepicker">
								<input type="text" class="form-control" name="active_till" value="<?= set_value('active_till'); ?>" data-date-format="yyyy-mm-dd">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Assign To*</label>
							<select class="form-control" name="employee_id" id="employeeIdDropdown">
								<option value="-1">No employee selected</option>
								<?php foreach ($Employees as $employee) : ?>
									<option value="<?= $employee->employee_id ?>"><?= $employee->employee_username; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('active_from', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('active_till', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row" style="display: none">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleInputEmail1">Inventory Selected*</label>
					<div id="dynamicInventSelected"></div>
				</div>
			</div>
		</div>
		<a href="<?= base_url('Catalogue/ViewCatalogueAssignments'); ?>">
			<button type="button" id="backFromCataloguesAssignmentButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="assignCatalogueButton" class="btn btn-primary">Assign Catalogue</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap-datepicker.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/AssignCatalogue.js').'?v='.time(); ?>"></script>

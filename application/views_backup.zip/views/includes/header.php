<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<title>DANPAK</title>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="hencework"/>
	<link rel="shortcut icon" href="">
	<link rel="icon" href="" type="image/x-icon">
	<link href="<?= base_url('assets/vendors/bower_components/dropify/dist/css/dropify.min.css').'?v='.time(); ?>" rel="stylesheet" type="text/css"/>	
	<link href="<?= base_url('assets/vendors/bower_components/datatables/media/css/jquery.dataTables.min.css').'?v='.time(); ?>" rel="stylesheet" type="text/css"/>	
	<link href="<?= base_url('assets/vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.min.css').'?v='.time(); ?>" rel="stylesheet" type="text/css"/>	
	<link href="<?= base_url('assets/dist/css/style.css').'?v='.time(); ?>" rel="stylesheet" type="text/css"/>	
</head>
<body>
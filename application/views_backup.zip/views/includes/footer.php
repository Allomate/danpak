
<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12 align-center">
				<p>2018 &copy; Allomate All rights reserved</p>
			</div>
		</div>
	</div>
</footer>

<script src="<?= base_url('assets/vendors/bower_components/jquery/dist/jquery.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/dropify/dist/js/dropify.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/dist/js/form-file-upload-data.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/dist/js/init.js').'?v='.time(); ?>"></script> 
<script src="<?= base_url('assets/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/dist/js/dataTables-data.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/select2/dist/js/select2.full.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js').'?v='.time(); ?>"></script> 
<script src="<?= base_url('assets/vendors/bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js').'?v='.time(); ?>"></script> 
<script type="text/javascript" src="<?= base_url('assets/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js').'?v='.time(); ?>"></script> 
<script src="<?= base_url('assets/dist/js/form-advance-data.js').'?v='.time(); ?>"></script> 
<script src="<?= base_url('assets/dist/js/jquery.slimscroll.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/vendors/bower_components/switchery/dist/switchery.min.js').'?v='.time(); ?>"></script>
<script src="<?= base_url('assets/dist/js/dropdown-bootstrap-extended.js').'?v='.time(); ?>"></script>	

</body>
</html>
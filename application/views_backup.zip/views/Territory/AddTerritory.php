<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addTerritoryForm');
	echo form_open('Territories/AddTerritoryOps', $attributes); ?>
	<fieldset>
		<legend>Add Territory</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Territory Name*</label>
							<input type="text" name="territory_name" value="<?= set_value('territory_name'); ?>" class="form-control" placeholder="Enter Territory name" maxlength="100"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Territory POC*</label>
							<select class="form-control" name="territory_poc_id">
								<?php foreach( $employees as $employee ) : ?>
									<option value="<?= $employee->employee_id; ?>"><?= $employee->employee_username; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Area*</label>
							<select class="form-control" name="area_id" id="areaIdDD">
								<?php foreach( $areas as $area ) : ?>
									<option value="<?= $area->id; ?>"><?= $area->area_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('territory_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Territories/ListTerritories'); ?>">
			<button type="button" id="backFromTerritoryButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addTerritoryButton" class="btn btn-primary">Add Territory</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/RegionAndArea.js').'?v='.time(); ?>"></script>

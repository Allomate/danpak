<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Territories/AddTerritory');?>">
		<button type="button" class="btn btn-success">ADD TERRITORy</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('territory_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('territory_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('territory_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('territory_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('territory_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('territory_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Territory Poc</th>
				<th>Area</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Territories as $territory) : ?>
				<tr>
					<td><?= $territory->territory_name; ?></td>
					<td><?= $territory->territory_poc; ?></td>
					<td><?= $territory->area_name; ?></td>
					<td>
						<a href="<?= base_url('Territories/UpdateTerritory/'.$territory->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Territories/DeleteTerritory/'.$territory->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
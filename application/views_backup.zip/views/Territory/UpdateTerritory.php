<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateTerritoryForm');
	echo form_open('Territories/UpdateTerritoryOps/'.$territory->id, $attributes); ?>
	<fieldset>
		<legend>Update Territory</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Territory Name*</label>
							<input type="text" name="territory_name" value="<?= $territory->territory_name; ?>" class="form-control" placeholder="Enter Territory name" maxlength="100"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail12">Territory POC*</label>
							<?php
							foreach ($employees as $employee) : 
								$options[$employee->employee_id] = $employee->employee_username;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('territory_poc_id', $options, $territory->territory_poc_id, $atts); ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Area*</label>
							<?php
							if ($areas) :
								foreach ($areas as $area) : 
									$optionsNew[$area->id] = $area->area_name;
								endforeach; 
								$atts = array( 'class' => 'form-control', 'id' => 'areaIdDD' );
								echo form_dropdown('area_id', $optionsNew, $territory->area_id, $atts); 
							else:
								$optionsNew[0] = "Please select an area";
								$atts = array( 'class' => 'form-control', 'id' => 'areaIdDD' );
								echo form_dropdown('area_id', $optionsNew, $territory->area_id, $atts); 
							endif;
							?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('territory_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Territories/ListTerritories'); ?>">
			<button type="button" id="backFromTerritoryButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateTerritoryButton" class="btn btn-primary">Update Territory</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/RegionAndArea.js').'?v='.time(); ?>"></script>

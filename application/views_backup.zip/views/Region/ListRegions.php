<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Regions/AddRegion');?>">
		<button type="button" class="btn btn-success">ADD REGION</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('region_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('region_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('region_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('region_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('region_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('region_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Region Poc</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Regions as $region) : ?>
				<tr>
					<td><?= $region->region_name; ?></td>
					<td><?= $region->region_poc; ?></td>
					<td>
						<a href="<?= base_url('Regions/UpdateRegion/'.$region->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Regions/DeleteRegion/'.$region->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addInventoryForm');
	echo form_open_multipart('Inventory/AddInventoryOps', $attributes); ?>
	<fieldset>
		<legend>Add Inventory</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Sku</label>
							<input type="text" name="item_sku" value="<?= set_value('item_sku'); ?>" class="form-control" placeholder="Enter item sku"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Barcode</label>
							<input type="text" name="item_barcode" value="<?= set_value('item_barcode'); ?>" class="form-control" placeholder="Enter barcode">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_sku', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_barcode', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Name*</label>
							<input type="text" name="item_name" value="<?= set_value('item_name'); ?>" class="form-control" placeholder="Enter Item name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputPassword1">Item Brand*</label>
							<input type="text" class="form-control" name="item_brand" value="<?= set_value('item_brand'); ?>" placeholder="Item Brand">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_brand', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Size*</label>
							<input type="text" name="item_size" value="<?= set_value('item_size'); ?>" class="form-control" placeholder="Enter item size" />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Expiry Date*</label>
							<input type="date" class="form-control" value="<?= set_value('item_expiry'); ?>" name="item_expiry" placeholder="Select expiry" />
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_size', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_expiry', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Purchase Price*</label>
							<input type="number" class="form-control" value="<?= set_value('item_purchased_price'); ?>" name="item_purchased_price" placeholder="Enter purchase price" />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Sell Price*</label>
							<input type="number" name="item_sale_price" value="<?= set_value('item_sale_price'); ?>" class="form-control" placeholder="Enter selling price" />
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_purchased_price', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('item_sale_price', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Images</label>
							<input type="file" id="item_images" name="item_images[]" data-input="false" multiple="multiple" class="form-control" accept=".png, .jpeg, .jpg, .bmp">
							<small>Max 3 Mb</small>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Item Thumbnail</label>
							<input type="file" id="item_thumbnail" name="item_thumbnail" data-input="false" class="form-control" accept=".png, .jpeg, .jpg, .bmp">
							<small>Max 3 Mb</small>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php if(isset($item_thumbnail_error)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $item_thumbnail_error; ?> </div> <?php endif;
				if(isset($imagesUploadError)) : ?> <div class="alert alert-dismissible alert-danger"> <?= $imagesUploadError; ?> </div> <?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="form-group">
					<label for="exampleInputEmail1">Item Description</label>
					<textarea type="text" name="item_description" class="form-control" placeholder="Enter item Description" rows="5"><?= set_value('item_description'); ?></textarea>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('item_description', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Inventory/ListInventory'); ?>">
			<button type="button" id="backFromInventoryButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addItemButton" class="btn btn-primary">Add Item</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Inventory.js').'?v='.time(); ?>"></script>

<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Inventory/AddInventory');?>">
		<button type="button" class="btn btn-success">ADD INVENTORY</button>
	</a>
	<hr>
	<?php
	if (isset($inventory_add_successfull)) : ?>
	<div class="alert alert-dismissible alert-success">
		<strong>Added!</strong> <?= $inventory_add_successfull; ?>
	</div>
<?php endif;
if (isset($inventory_update_successfull)) : ?>
<div class="alert alert-dismissible alert-success">
	<strong>Updated!</strong> <?= $inventory_update_successfull; ?>
</div>
<?php endif;
if (isset($inventory_update_failed)) : ?>
<div class="alert alert-dismissible alert-danger">
	<strong>Failed!</strong> <?= $inventory_update_failed; ?>
</div>
<?php endif;
if (isset($success_deleted)) : ?>
<div class="alert alert-dismissible alert-success">
	<strong>Deleted</strong> <?= $success_deleted; ?>
</div>
<?php endif;
if (isset($delete_failed)) : ?>
<div class="alert alert-dismissible alert-danger">
	<strong>Failed</strong> <?= $delete_failed; ?>
</div>
<?php endif;
if (isset($inventory_add_failed)) : ?>
<div class="alert alert-dismissible alert-danger">
	<strong>Failed</strong> <?= $inventory_add_failed; ?>
</div>
<?php endif;
if ($feedback = $this->session->flashdata('update_success')) : ?>
<div class="alert alert-dismissible alert-success">
	<strong>Updated</strong> <?= $feedback; ?>
</div>
<?php endif;
if ($feedback = $this->session->flashdata('update_failed')) : ?>
<div class="alert alert-dismissible alert-danger">
	<strong>Failed</strong> <?= $feedback; ?>
</div>
<?php endif; ?>
<br>
<div>
	<img src="<?= base_url('assets/images/table-loader.gif'); ?>" style="top: 40%; left: 50%; position: absolute; width: auto; height: 90px" id="loaderImg">
	<table class="table table-hover" style="display: none">
		<thead>
			<tr>
				<th>Sku</th>
				<th>Name</th>
				<th>Brand</th>
				<th>Price</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($inventoryList as $inventory) : ?>
				<tr>
					<td><?= $inventory->item_sku; ?></td>
					<td><?= $inventory->item_name; ?></td>
					<td><?= $inventory->item_brand; ?></td>
					<td><?= $inventory->item_purchased_price; ?></td>
					<td>
						<a href="<?= base_url('Inventory/UpdateInventory/'.$inventory->item_id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Inventory/DeleteInventory/'.$inventory->item_id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Inventory.js').'?v='.time(); ?>"></script>
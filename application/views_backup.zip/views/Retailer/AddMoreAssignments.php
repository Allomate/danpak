<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php if ($feedback = $this->session->flashdata('missing_information')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Missing Information!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addRetailerAssignmentForm');
	echo form_open('Retailers/RetailerAssignemntOps', $attributes); ?>
	<fieldset>
		<legend>Assign Distributors</legend>
		<div class="row">
			<div class="col-md-6">
				<label>Select Employee</label>
				<select class="form-control" name="employee">
					<?php foreach ($Employees as $employee): ?>
						<option value="<?= $employee->employee_id; ?>"><?= $employee->employee_username; ?></option>
					<?php endforeach ?>
				</select>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<label>Distributors Added</label>
				<ul style="list-style: none; padding: 0px" id="addedAssignmentsList">
				</ul>
			</div>
		</div>
		<div class="row">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>Distributor Name</th>
						<th>Distributor Address</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($Distributors as $retailer) : ?>
						<tr>
							<td><?= $retailer->retailer_name; ?></td>
							<td><?= $retailer->retailer_address; ?></td>
							<td>
								<input type="number" value="<?= $retailer->id; ?>" hidden>
								<button type="button" class="btn btn-danger addRetailerForAssignment">ADD</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<input type="text" name="retailersForAssignments" id="retailersForAssignments" hidden>

		<a href="<?= base_url('Retailers/ListRetailersAssignments'); ?>">
			<button type="button" id="backFromRetailersAssignmentsButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addRetailersAssignmentsButton" class="btn btn-primary">Add Assignment</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Retailers.js').'?v='.time(); ?>"></script>

<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addRetailerForm');
	echo form_open('Retailers/AddRetailerOps', $attributes); ?>
	<fieldset>
		<legend>Add Distributor</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Name*</label>
							<input type="text" name="retailer_name" value="<?= set_value('retailer_name'); ?>" class="form-control" placeholder="Enter Distributor name" maxlength="100"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Territory*</label>
							<select class="form-control" name="retailer_territory_id">
								<?php foreach( $Territories as $territory ) : ?>
									<option value="<?= $territory->id; ?>"><?= $territory->territory_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('retailer_territory_id', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Phone</label>
							<input type="text" name="retailer_phone" value="<?= set_value('retailer_phone'); ?>" class="form-control" placeholder="Enter Distributor Phone" maxlength="100">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Email</label>
							<input type="email" name="retailer_email" value="<?= set_value('retailer_email'); ?>" class="form-control" placeholder="Enter Distributor Email" maxlength="100">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_phone', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('retailer_email', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Latitude</label>
							<input type="text" name="retailer_lats" value="<?= set_value('retailer_lats'); ?>" class="form-control" placeholder="Enter Distributor Latitude" maxlength="100">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Longitude</label>
							<input type="text" name="retailer_longs" value="<?= set_value('retailer_longs'); ?>" class="form-control" placeholder="Enter Distributor Longitude" maxlength="100">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_lats', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('retailer_longs', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Type*</label>
							<select class="form-control" name="retailer_type_id">
								<?php foreach( $RetailerTypes as $type ) : ?>
									<option value="<?= $type->id; ?>"><?= $type->retailer_type_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor City*</label>
							<input type="text" name="retailer_city" value="<?= set_value('retailer_city'); ?>" class="form-control" placeholder="Enter Distributor City" maxlength="100">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_type_id', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('retailer_city', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Address*</label>
							<textarea type="text" name="retailer_address" class="form-control" placeholder="Enter Address" rows="5"><?= set_value('retailer_address'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_address', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Retailers/ListRetailers'); ?>">
			<button type="button" id="backFromRetailersButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addRetailerButton" class="btn btn-primary">Add Distributor</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Retailers.js').'?v='.time(); ?>"></script>

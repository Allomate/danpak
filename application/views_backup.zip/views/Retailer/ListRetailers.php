<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Retailers/AddRetailer');?>">
		<button type="button" class="btn btn-success">ADD Distributor</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('retailer_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Address</th>
				<th>Territory</th>
				<th>Type</th>
				<th>Created at</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Distributors as $retailer) : ?>
				<tr>
					<td><?= $retailer->retailer_name; ?></td>
					<td><?= $retailer->retailer_address; ?></td>
					<td><?= $retailer->territory_name; ?></td>
					<td><?= $retailer->retailer_type; ?></td>
					<td>
						<a href="<?= base_url('Retailers/UpdateRetailer/'.$retailer->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Retailers/DeleteRetailer/'.$retailer->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
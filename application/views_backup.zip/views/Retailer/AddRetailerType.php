<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addRetailerTypeForm');
	echo form_open('Retailers/AddRetailerTypeOps', $attributes); ?>
	<fieldset>
		<legend>Add Distributor Type</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Distributor Type Name*</label>
							<input type="text" name="retailer_type_name" value="<?= set_value('retailer_type_name'); ?>" class="form-control" placeholder="Enter Distributor Type" maxlength="100"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Discount</label>
							<input type="number" name="discount" value="<?= set_value('discount'); ?>" class="form-control" placeholder="Discount on Type" min="0"> 
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('retailer_type_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
				<?php echo form_error('discount', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Retailers/ListRetailerTypes'); ?>">
			<button type="button" id="backFromRetailersTypeButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addRetailerTypeButton" class="btn btn-primary">Add Distributor Type</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Retailers.js').'?v='.time(); ?>"></script>

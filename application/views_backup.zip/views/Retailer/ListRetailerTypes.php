<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Retailers/AddRetailerType');?>">
		<button type="button" class="btn btn-success">ADD Distributor type</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('retailer_type_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_type_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_type_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_type_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_type_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_type_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Type Name</th>
				<th>Discount</th>
			</tr>
		</thead>
		<tbody>
			<?php $counter = 1; foreach ($RetailerTypes as $type) : ?>
				<tr>
					<td><?= $counter++; ?></td>
					<td><?= $type->retailer_type_name; ?></td>
					<td><?= $type->discount; ?></td>
					<td>
						<a href="<?= base_url('Retailers/UpdateRetailerType/'.$type->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Retailers/DeleteRetailerType/'.$type->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
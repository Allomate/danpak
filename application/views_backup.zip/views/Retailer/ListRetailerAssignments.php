<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Retailers/AddMoreAssignments');?>">
		<button type="button" class="btn btn-success">Add more assignments</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('retailer_assignment_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_assignment_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_assignment_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_assignment_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('retailer_assignment_Exist')) : ?>
		<div class="alert alert-dismissible alert-warning">
			<strong>Already Exist!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('assignment_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('assignment_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Distributors</th>
				<th>Addresses</th>
				<th>Employee</th>
				<th>Created at</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($RetailersAssignments as $assignment) : ?>
				<tr>
					<td><?= $assignment->retailer_names; ?></td>
					<td><?= $assignment->retailer_addresses; ?></td>
					<td><?= $assignment->employee; ?></td>
					<td>
						<a href="<?= base_url('Retailers/UpdateRetailersAssignments/'.$assignment->employee_id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Retailers/DeleteRetailersAssignments/'.$assignment->employee_id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
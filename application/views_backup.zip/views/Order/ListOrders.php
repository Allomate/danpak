<?php require_once(APPPATH.'/views/includes/header.php'); ?>
<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<hr>

	<?php if ($feedback = $this->session->flashdata('order_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_processed')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Processed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_process_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_completed')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Completed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_complete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_cancelled')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Cancelled!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>

	<?php if ($feedback = $this->session->flashdata('order_cancel_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed!</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Order#</th>
				<th style="max-width: 150px">Order Items</th>
				<th>Distributor Name</th>
				<th>Booker Name</th>
				<th>Booking Date</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Orders as $order) : ?>
				<tr>
					<td><?= $order->id; ?></td>
					<td style="max-width: 200px"><?= $order->item_name; ?></td>
					<td><?= $order->distributor_name; ?></td>
					<td><?= $order->employee_username; ?></td>
					<td><?= $order->created_at; ?></td>
					<td><?= $order->status ? $order->status : "Awaiting"; ?></td>
					<td>
						<?php if ($order->status == "Processed") : ?>
							<a href="<?= base_url('Orders/CompleteOrder/'.$order->id); ?>">
								<button class="btn btn-sm btn-success">Complete</button>
								&nbsp;
								<a href="<?= base_url('Orders/UpdateOrder/'.$order->id); ?>">
									<button class="btn btn-sm btn-secondary">Update</button>
								</a>
								&nbsp;
								<a href="<?= base_url('Orders/CancelOrder/'.$order->id); ?>">
									<button class="btn btn-sm btn-danger">Cancel</button>
								</a>
							</a>
						<?php elseif (!$order->status) : ?>
							<a href="<?= base_url('Orders/ProcessOrder/'.$order->id); ?>">
								<button class="btn btn-sm btn-success">Process</button>
							</a>
							&nbsp;
							<a href="<?= base_url('Orders/UpdateOrder/'.$order->id); ?>">
								<button class="btn btn-sm btn-secondary">Update</button>
							</a>
							&nbsp;
							<a href="<?= base_url('Orders/CancelOrder/'.$order->id); ?>">
								<button class="btn btn-sm btn-danger">Cancel</button>
							</a>
						<?php else: ?>
							<span style="font-weight: bold; text-align: center">No action needed</span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
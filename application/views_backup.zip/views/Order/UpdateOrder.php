<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php 
	// echo "<pre>";print_r($Order->items);die;
	$attributes = array('class' => 'form-control', 'id' => 'updateOrderForm');
	echo form_open_multipart('Orders/UpdateOrderOps/'.$Order->id, $attributes);
	// echo form_hidden('items_deleted', '');
	echo form_hidden('existing_items', '');
	echo form_hidden('existing_quantities', '');?>
	<input type="text" name="items_deleted" class="form-control">
	<fieldset>
		<center>
			<h3>Stock Order</h3>
		</center>
		<table class="table table-hover stockOrderTable" style="display: none">
			<thead>
				<tr>
					<th>Sku</th>
					<th>Item</th>
					<th>Unit Type</th>
					<th>Unit Price</th>
					<th>Quantity</th>
					<th>Quantity Available</th>
					<th>Individual Discount</th>
					<th>Sub-Total</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($Order->items as $item) : ?>
					<tr>
						<td><?= $item['item_details']->item_sku; ?></td>
						<td><?= $item['item_details']->item_name; ?></td>
						<td><?= $item['item_details']->unit_name; ?></td>
						<td><?= $item['item_details']->after_discount; ?></td>
						<td>
							<input class="form-control form-control-sm" name="item_quantity_booker_existing" type="number" placeholder="Quantity" min="1" id="iqmasdas" value="<?= $item['item_quantity_booker']; ?>">
							<input name="item_id_existing" type="number" value="<?= $item['item_details']->pref_id; ?>" hidden>
						</td>
						<td><?= $item['item_details']->item_quantity; ?></td>
						<td><?= $item['booker_discount'] ? $item['booker_discount'].'%' : 'No Discount'; ?></td>
						<td><?= $item['final_price']; ?></td>
						<td>
							<button class="btn btn-sm btn-danger removeItemFromStockOrderBtn" type="button" id="<?= $item['order_content_id'];?>">REMOVE</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="9" style="text-align: center;">
						<button style="width: 100%" class="btn btn-success updateStockQuantityBtn" type="button">UPDATE STOCK ORDER</button>
					</th>
				</tr>
			</tfoot>
		</table>
	</fieldset>
</form>
<hr>
<center>
	<h3>Expand Order</h3>
</center>
<?php 
$attributes = array('class' => 'form-control', 'id' => 'expandOrderForm');
echo form_open_multipart('Orders/ExpandOrderOps/'.$Order->id, $attributes);
echo form_hidden('item_quantities_expansion', '');
echo form_hidden('booker_discounts_expansion', '');
echo form_hidden('item_ids_expansion', '');?>
<div class="row" id="dynamicInventoryExpansionDiv" style="display: none">
</div>
<fieldset>
	<div style="display: block">
		<table class="table table-hover inventoryTable" style="display: none">
			<thead>
				<tr>
					<th>Sku</th>
					<th>Item</th>
					<th>Unit</th>
					<th>Price</th>
					<th>Quantity</th>
					<th>Quantity Available</th>
					<th>Booker Discount</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($Inventory as $inventory) : ?>
					<tr>
						<td><?= $inventory->item_sku; ?></td>
						<td><?= $inventory->item_name; ?></td>
						<td><?= $inventory->unit_name; ?></td>
						<td><?= $inventory->after_discount; ?></td>
						<td>
							<input class="form-control form-control-sm" name="item_quantity" type="number" placeholder="Quantity" min="1">
						</td>
						<td><?= $inventory->item_quantity; ?></td>
						<td>
							<input class="form-control form-control-sm" name="booker_discount" type="number" placeholder="Discount" min="0" max="100" style="width: 100%" value="0">
						</td>
						<td>
							<button class="btn btn-sm btn-success addQuantityBtn" type="button" id="<?= $inventory->pref_id;?>">ADD</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<hr>
	<button type="button" id="expandOrderButton" class="btn btn-primary" style="width: 100%">Expand Order</button>
	<a href="<?= base_url('Orders/ListOrders'); ?>" style="margin-top: 10px; display: block">
		<button type="button" id="backFromOrdersBtn" class="btn btn-secondary" style="width: 100%">Back</button>
	</a>
</fieldset>
</form>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Order.js').'?v='.time(); ?>"></script>
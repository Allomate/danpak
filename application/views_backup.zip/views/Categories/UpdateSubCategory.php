<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateSubCategoryForm');
	echo form_open('Categories/UpdateSubCategoryOps/'.$SubCategory->sub_category_id, $attributes); ?>
	<fieldset>
		<legend>Main Category</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Category Name*</label>
							<input type="text" name="sub_category_name" value="<?= $SubCategory->sub_category_name; ?>" class="form-control" placeholder="Enter Category name" maxlength="100"> 
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Main Category</label>
							<?php
							foreach ($MainCategories as $category) : 
								$options[$category->main_category_id] = $category->main_category_name;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('main_category_id', $options, $SubCategory->main_category_id, $atts); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('sub_category_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Categories/ListSubCategories'); ?>">
			<button type="button" id="backFromUpdateSubCategories" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateSubCatButton" class="btn btn-primary">Update Category</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/Categories.js').'?v='.time(); ?>"></script>

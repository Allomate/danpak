<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Categories/AddMainCategory');?>">
		<button type="button" class="btn btn-success">ADD Main Category</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('main_category_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_activated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Activated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_activate_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_deactivated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>De-Activated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('main_category_deactivate_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Category Name</th>
				<th>Category Status</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $sno = 1; foreach ($MainCategories as $category) : ?>
			<tr>
				<td><?= $sno++; ?></td>
				<td><?= $category->main_category_name; ?></td>
				<td><?= $category->is_active ? "Active" : 'In Active'; ?></td>
				<td>
					<a href="<?= base_url('Categories/UpdateMainCategory/'.$category->main_category_id); ?>">
						<button class="btn btn-sm btn-secondary">Update</button>
					</a>
					&nbsp;
					<?php if($category->is_active) : ?>
						<a href="<?= base_url('Categories/DeactivateMainCategory/'.$category->main_category_id); ?>">
							<button class="btn btn-sm btn-warning">De-Activate</button>
						</a>
					<?php else: ?>
						<a href="<?= base_url('Categories/ActivateMainCategory/'.$category->main_category_id); ?>">
							<button class="btn btn-sm btn-warning">Activate</button>
						</a>
					<?php endif;?>
					&nbsp;
					<a href="<?= base_url('Categories/DeleteMainCategory/'.$category->main_category_id); ?>">
						<button class="btn btn-sm btn-danger">Delete</button>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Categories/AddSubCategory');?>">
		<button type="button" class="btn btn-success">ADD Sub Category</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('sub_category_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_category_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_category_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_category_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_category_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('sub_category_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>S.No</th>
				<th>Category Name</th>
				<th>Main Category</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $sno = 1; foreach ($SubCategories as $category) : ?>
			<tr>
				<td><?= $sno++; ?></td>
				<td><?= $category->sub_category_name; ?></td>
				<td><?= $category->main_category_name; ?></td>
				<td>
					<a href="<?= base_url('Categories/UpdateSubCategory/'.$category->sub_category_id); ?>">
						<button class="btn btn-sm btn-secondary">Update</button>
					</a>
					&nbsp;
					<a href="<?= base_url('Categories/DeleteSubCategory/'.$category->sub_category_id); ?>">
						<button class="btn btn-sm btn-danger">Delete</button>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
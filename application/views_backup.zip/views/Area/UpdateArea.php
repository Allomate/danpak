<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'updateAreaForm');
	echo form_open('Areas/UpdateAreaOps/'.$area->id, $attributes); ?>
	<fieldset>
		<legend>Update Area</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Area Name*</label>
							<input type="text" name="area_name" value="<?= $area->area_name; ?>" class="form-control" placeholder="Enter Region name" maxlength="100"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail12">Area POC*</label>
							<?php
							foreach ($employees as $employee) : 
								$options[$employee->employee_id] = $employee->employee_username;
							endforeach; 
							$atts = array( 'class' => 'form-control' );
							echo form_dropdown('area_poc_id', $options, $area->area_poc_id, $atts); ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Region*</label>
							<?php
							if ($regions) :
								foreach ($regions as $region) : 
									$optionsNew[$region->id] = $region->region_name;
								endforeach; 
								$atts = array( 'class' => 'form-control', 'id' => 'regionIdDD' );
								echo form_dropdown('region_id', $optionsNew, $area->region_id, $atts);
							else:
								$optionsNew[0] = "Please select a region";
								$atts = array( 'class' => 'form-control', 'id' => 'regionIdDD' );
								echo form_dropdown('region_id', $optionsNew, $area->region_id, $atts);
							endif;
							?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('area_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Areas/ListAreas'); ?>">
			<button type="button" id="backFromAreasButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="updateAreaButton" class="btn btn-primary">Update Area</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/RegionAndArea.js').'?v='.time(); ?>"></script>

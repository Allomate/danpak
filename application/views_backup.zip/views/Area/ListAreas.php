<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<hr>
	<a href="<?= base_url('Dashboard');?>">
		<button type="button" class="btn btn-primary">Dashboard</button>
	</a>
	<a href="<?= base_url('Areas/AddArea');?>">
		<button type="button" class="btn btn-success">ADD AREA</button>
	</a>
	<hr>
	<?php if ($feedback = $this->session->flashdata('area_added')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Added</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('area_add_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('area_updated')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Updated</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('area_update_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('area_deleted')) : ?>
		<div class="alert alert-dismissible alert-success">
			<strong>Deleted</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<?php if ($feedback = $this->session->flashdata('area_delete_failed')) : ?>
		<div class="alert alert-dismissible alert-danger">
			<strong>Failed</strong> <?= $feedback; ?>
		</div>
	<?php endif; ?>
	<br>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Area Poc</th>
				<th>Region</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($Areas as $area) : ?>
				<tr>
					<td><?= $area->area_name; ?></td>
					<td><?= $area->area_poc; ?></td>
					<td><?= $area->region_name; ?></td>
					<td>
						<a href="<?= base_url('Areas/UpdateArea/'.$area->id); ?>">
							<button class="btn btn-sm btn-secondary">Update</button>
						</a>
						&nbsp;
						<a href="<?= base_url('Areas/DeleteArea/'.$area->id); ?>">
							<button class="btn btn-sm btn-danger">Delete</button>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
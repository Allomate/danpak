<?php require_once(APPPATH.'/views/includes/header.php'); ?>

<div class="container">
	<br>
	<?php $attributes = array('class' => 'form-control', 'id' => 'addAreaForm');
	echo form_open('Areas/AddAreaOps', $attributes); ?>
	<fieldset>
		<legend>Add Area</legend>
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleInputEmail1">Area Name*</label>
							<input type="text" name="area_name" value="<?= set_value('area_name'); ?>" class="form-control" placeholder="Enter Area name" maxlength="100"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Area POC*</label>
							<select class="form-control" name="area_poc_id">
								<?php foreach( $employees as $employee ) : ?>
									<option value="<?= $employee->employee_id; ?>"><?= $employee->employee_username; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Region*</label>
							<select class="form-control" name="region_id" id="regionIdDD">
								<?php foreach( $regions as $region ) : ?>
									<option value="<?= $region->id; ?>"><?= $region->region_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<?php echo form_error('area_name', '<div class="alert alert-dismissible alert-danger">', '</div>');?>
			</div>
		</div>
		<a href="<?= base_url('Areas/ListAreas'); ?>">
			<button type="button" id="backFromAreasButton" class="btn btn-secondary">Back</button>
		</a>
		&nbsp;
		<button type="button" id="addAreaButton" class="btn btn-primary">Add Area</button>
	</fieldset>
</form>

</div>

<?php require_once(APPPATH.'/views/includes/footer.php'); ?>
<!-- Page level JS -->
<script type="text/javascript" src="<?= base_url('assets/js/RegionAndArea.js').'?v='.time(); ?>"></script>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<title>DANPAK</title>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="hencework" />
	<link rel="shortcut icon" href="">
	<link rel="icon" href="" type="image/x-icon">

	<link href="<?= base_url('assets/vendors/bower_components/dropify/dist/css/dropify.min.css'); ?>" rel="stylesheet" type="text/css"
	/>
	<link href="<?= base_url('assets/vendors/bower_components/datatables/media/css/jquery.dataTables.min.css'); ?>" rel="stylesheet"
	type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.min.css'); ?>" rel="stylesheet"
	type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.css'); ?>" rel="stylesheet"
	type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css'); ?>"
	rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/multiselect/css/multi-select.css'); ?>" rel="stylesheet" type="text/css"
	/>
	<link href="<?= base_url('assets/vendors/bower_components/jquery-wizard.js/css/wizard.css'); ?>" rel="stylesheet" type="text/css"
	/>
	<link href="<?= base_url('assets/vendors/bower_components/jquery.steps/demo/css/jquery.steps.css'); ?>" rel="stylesheet"
	type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/nestable2/jquery.nestable.css'); ?>" rel="stylesheet" type="text/css"
	/>
	<link href="<?= base_url('assets/css/bootstrap-duallistbox.css'); ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css'); ?>"
	rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/multi/multi.min.css'); ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/css/style.css?v=1.1.1'); ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/dist/css/style.css?v=2.2'); ?>" rel="stylesheet" type="text/css" />
	<link href="<?= base_url('assets/dist/css/select2.min.css'); ?>" rel="stylesheet" type="text/css" />
</head>

<body>

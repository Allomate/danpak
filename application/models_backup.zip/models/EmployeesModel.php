<?php

class EmployeesModel extends CI_Model{

	public function get_employees_list(){
		return $this->db->select('employee_id, employee_username, employee_first_name, employee_last_name, (SELECT employee_username from employees_info where employee_id = ei.reporting_to) reporting_to')->get("employees_info ei")->result();
	}

	public function add_employee($employee){
		return $this->db->insert('employees_info', $employee);
	}

	public function get_single_employee($employee_id){
		return $this->db->where('employee_id', $employee_id)->get("employees_info")->row();
	}

	public function update_employee($employee_id, $employee){
		if (isset($employee['employee_picture']) || $employee['picture_deleted'] == 'deleted') {
			$employee_picture = $this->db->select('REPLACE(employee_picture,"./","") as employee_picture')->where('employee_id', $employee_id)->get('employees_info')->row()->employee_picture;
			if ($employee_picture) {
				$employee_picture = FCPATH.$employee_picture;
				if (file_exists($employee_picture)) {
					unlink($employee_picture);
				}
			}
			unset($employee['picture_deleted']);
			if (!isset($employee['employee_picture'])) {
				$employee['employee_picture'] = '';
			}
		}else if(!isset($employee['employee_picture']) && $employee['picture_deleted'] == 'deleted'){
			$employee['employee_picture'] = '';
			unset($employee['picture_deleted']);
		}else{
			unset($employee['picture_deleted']);
		}
		return $this->db
		->where('employee_id',$employee_id)	
		->update('employees_info', $employee);
	}

	public function delete_employee($employee_id){
		return $this->db->delete('employees_info', array('employee_id' => $employee_id)); 
	}

}

?>